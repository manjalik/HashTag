package mypakage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HashTagProject {

	public static void main(String[] args) {
         WebDriver driver;
		
		//Browser opening and URL loading
		driver = WebDriverManager.chromedriver().create(); 
		driver.get("https://www.hashtag-ca.com/careers/apply?jobCode=QAE001");
		driver.manage().window().maximize();
		
		//Form filling
		//Name
		driver.findElement(By.xpath("//input[@placeholder='Enter your name']")).sendKeys("Manjali");
		//Email
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("abc@gmail.com");
		//Phone
		driver.findElement(By.xpath("//input[@placeholder='Enter your phone']")).sendKeys("974987545");
		//Resume uploading
		WebElement uploadElement = driver.findElement(By.id("inputFile"));
		uploadElement.sendKeys("C:\\Users\\ADMIN\\Desktop\\Resume\\Resume_Manjali Kuldharan.pdf");
		//Description	
		driver.findElement(By.xpath("//textarea[@placeholder='Briefly Describe Yourself']")).sendKeys("I am a Test Engineer");
		//Submit button		
		driver.findElement(By.xpath("//button[@class='btn form-button-child px-3']")).submit();
				
		//closing the browser
		driver.close();

	}

}
